import React, { useEffect, useState } from 'react'
import { Button } from 'react-bootstrap'

export default function Cart() {

    return (
        <div className='d-flex'>
            <h5>Cart Delivery Address</h5>

        </div>
    )
}
